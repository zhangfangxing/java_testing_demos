package com.zfx;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

public class test1 {

    @Benchmark
    public void wellHelloThere() {
        //空函数
    }

    public static void main(String[] args) throws RunnerException {
        Options opt = new OptionsBuilder()
                .include(test1.class.getSimpleName())
                .forks(1)
                .build();

        new Runner(opt).run();
    }
}
