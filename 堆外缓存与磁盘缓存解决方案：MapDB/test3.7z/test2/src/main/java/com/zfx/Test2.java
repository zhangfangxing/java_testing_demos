package com.zfx;

import java.util.concurrent.ConcurrentMap;
import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.Serializer;

/**
 * 初次使用MapDB2
 */
public class Test2 {

    public static void main(String[] args) {
        DB db = DBMaker.fileDB("file.db").make();
        ConcurrentMap<String,Long> map = db.hashMap("map", Serializer.STRING, Serializer.LONG).create();
        map.put("something", 123456L);
        db.close();//如果不关闭数据库，则可以正常获取数据
        System.out.println(String.valueOf(db.get("something")));
//异常：Exception in thread "main" java.lang.IllegalAccessError: DB was closed
    }
}
