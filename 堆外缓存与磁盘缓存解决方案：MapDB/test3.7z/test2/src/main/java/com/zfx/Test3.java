package com.zfx;

import org.mapdb.DB;
import org.mapdb.DBMaker;

/**
 * MapDB的构造
 */
public class Test3 {
    public static void main(String[] args) {
        DB db1 = DBMaker.fileDB("123.txt")
                .fileMmapEnable()
                .allocateStartSize(10*1024*1024*1024)// 分配起始大小10GB
                .allocateIncrement(512*1024*1024)// 分配增量大小512MB
                .make();

        DB db2 = DBMaker.heapDB().make();

        DB.HashMapMaker<?,?> heapShardedHashMap = DBMaker.heapShardedHashMap(5);

        DB.HashSetMaker<?> heapShardedHashSet = DBMaker.heapShardedHashSet(5);

        DB db5 = DBMaker.memoryDB().transactionEnable().make();

        DB db6 = DBMaker.memoryDirectDB().make();

        DB.HashMapMaker<?,?> memoryShardedHashMap = DBMaker.memoryShardedHashMap(5);

        DB db8 = DBMaker.tempFileDB().make();
    }
}
