package com.zfx;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.HTreeMap;
import org.mapdb.Serializer;

import java.util.concurrent.ConcurrentMap;

/**
 *使用HashMap
 */
public class Test7 {
    public static void main(String[] args) {
        DB db = DBMaker.memoryDirectDB().make();
        HTreeMap<String, String> hashMap = db
                .hashMap("hashMap", Serializer.STRING, Serializer.STRING)
                .createOrOpen();
        hashMap.put("1", "2");
        System.out.println(hashMap.get("1"));//2

//        ConcurrentMap hashMap = db.hashMap("map").create();
//        hashMap.put("something", "here");
//        System.out.println(hashMap.get("something"));//here
    }
}
