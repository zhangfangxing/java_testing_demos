package com.zfx;
import java.util.concurrent.ConcurrentMap;
import org.mapdb.DB;
import org.mapdb.DBMaker;

/**
 * 初次使用MapDB1
 */
public class Test1 {
    public static void main(String[] args) {
        DB db = DBMaker.memoryDB().make();
        ConcurrentMap map = db.hashMap("map").create();
        map.put("something", "here");
        System.out.println(map.get("something"));//输出here
    }
}
