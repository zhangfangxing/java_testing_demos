package com.zfx;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.IndexTreeList;

/**
 * indexTreeList
 */
public class Test8 {
    public static void main(String[] args) {
        DB db = DBMaker.memoryDirectDB().make();
        IndexTreeList<Object> indexTreeList = db.indexTreeList("indexTreeList").createOrOpen();
        indexTreeList.add("indexTreeList1");
        indexTreeList.add("indexTreeList2");
        System.out.println(indexTreeList);//[indexTreeList1, indexTreeList2]
    }
}
