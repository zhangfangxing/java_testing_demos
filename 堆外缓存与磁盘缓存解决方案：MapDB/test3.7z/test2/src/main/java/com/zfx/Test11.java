package com.zfx;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.HTreeMap;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * MapDB的监听器与多级缓存
 */
public class Test11 {
    public static void main(String[] args) {
        DB dbDisk = DBMaker.fileDB("file").make();//初始化磁盘缓存
        DB dbMemory = DBMaker.memoryDB().make();//初始化堆内缓存

        // 过期数据存放onDisk磁盘缓存之中，由于磁盘缓存方便扩容，所以适合放大量数据
        HTreeMap onDisk = dbDisk.hashMap("onDisk").create();

        // 少量数据存放inMemory堆缓存之中，由于堆缓存较小，但速度更快，适合放热数据
        HTreeMap inMemory = dbMemory.hashMap("inMemory")
                .expireAfterGet(1, TimeUnit.SECONDS)//过期时间，此处设置为1秒
                .expireOverflow(onDisk) //此寄存器溢出到磁盘
                .expireExecutor(Executors.newScheduledThreadPool(2)) //启用后台过期
                .create();

        //同时在两个缓存中添加数据
        inMemory.put("name", "zfx");
        //移除堆内缓存中的name
        inMemory.remove("name");
        //在磁盘缓存中也无法获得name索引的数据
        onDisk.get("name"); //null

        System.out.println(onDisk.size());//0
        onDisk.put(1,"one");
        System.out.println(inMemory.size());//1
        //从堆内缓存中获取key值为1的数据，如果获取不到，则去onDisk磁盘缓存中获取
        System.out.println(inMemory.get(1)); //one
        //从onDisk磁盘缓存中获取key值外的数据之后，把它放置在堆内缓存中
        System.out.println(inMemory.size()); //> 1

        //也可以清除整个主map，并把所有数据移到磁盘中：
        inMemory.put(1,11);
        inMemory.put(2,11);

        //删除上面两条堆内缓存数据，它们会被 储进磁盘缓存中
        inMemory.clearWithExpire();
        System.out.println(onDisk.size());//2
        System.out.println(inMemory.size());//0
        System.out.println(inMemory.get(1));//11
        System.out.println(inMemory.size());//1
    }
}
