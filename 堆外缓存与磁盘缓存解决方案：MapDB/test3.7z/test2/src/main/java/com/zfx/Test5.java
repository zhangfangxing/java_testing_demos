package com.zfx;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.Serializer;
import org.mapdb.serializer.SerializerArrayTuple;

import java.util.NavigableSet;

/**
 * MapDB的使用
 */
public class Test5 {
    public static void main(String[] args) {
        DB db = DBMaker.memoryDirectDB().make();
        NavigableSet<Object[]> treeSet = db.treeSet("treeSet")
                .serializer(new SerializerArrayTuple(Serializer.STRING, Serializer.INTEGER))
                .createOrOpen();
        treeSet.add(new Object[]{"John",1});
        treeSet.add(new Object[]{"Lili",2});
        treeSet.add(new Object[]{"Anna",1});
        System.out.println(treeSet.first()[0]);//Anna
    }
}
