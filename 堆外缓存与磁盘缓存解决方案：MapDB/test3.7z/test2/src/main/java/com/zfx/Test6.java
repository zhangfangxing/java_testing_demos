package com.zfx;

import org.mapdb.BTreeMap;
import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.Serializer;

import java.util.Map;
import java.util.Set;

/**
 * 使用TreeMap
 */
public class Test6 {
    public static void main(String[] args) {
        DB db = DBMaker.memoryDirectDB().make();
        BTreeMap<byte[], Integer> map = db
                .treeMap("towns", Serializer.BYTE_ARRAY, Serializer.INTEGER)
                .createOrOpen();
        map.put("New York".getBytes(), 1);
        map.put("New Jersey".getBytes(), 2);
        map.put("Boston".getBytes(), 3);
        System.out.println(map.get("New Jersey".getBytes()));//2
        Set<Map.Entry<byte[],Integer>> entrySet = map.prefixSubMap("New".getBytes()).entrySet();
        for (Map.Entry<byte[], Integer> entry : entrySet) {
            System.out.println(new String(entry.getKey())+"---"+entry.getValue());
        //New Jersey---2
        //New York---1
        }
    }
}
