package com.zfx;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.Serializer;

import java.util.concurrent.ConcurrentMap;

/**
 * MapDB的事务
 */
public class Test10 {
    public static void main(String[] args) {
        DB db = DBMaker
                .fileDB("file3.db")
                .fileMmapEnable()
                .transactionEnable() //开启事务
                .closeOnJvmShutdown() //JVM关闭时关闭DB
                .make();
        ConcurrentMap<String,Long> map = db
                .hashMap("mapsl3", Serializer.STRING, Serializer.LONG)
                .createOrOpen();
        map.put("a", 1L);
        map.put("b", 2L);
        db.commit();
        System.out.println(map.get("a"));//1
        System.out.println(map.get("b"));//2
        map.put("c", 3L);
        System.out.println("rollback之前，c:" + map.get("c"));//3
        db.rollback();
        System.out.println("rollback之后，a:" + map.get("a"));//1
        System.out.println("rollback之后，c:" + map.get("c"));//null
    }
}
