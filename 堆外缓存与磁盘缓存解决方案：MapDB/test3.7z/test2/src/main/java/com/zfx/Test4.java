package com.zfx;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.HTreeMap;
import org.mapdb.Serializer;
import org.mapdb.volume.MappedFileVol;
import org.mapdb.volume.Volume;

import java.io.File;
import java.io.IOException;

/**
 * 在临时文件夹中创建新的数据库。如果程序关闭，则删除临时文件。
 */
public class Test4 {
    public static void main(String[] args) throws IOException {
        File f = File.createTempFile("some2","file2");
        Volume volume = MappedFileVol.FACTORY.makeVolume(f.getPath(),false);
        boolean contentAlreadyExists = false;
        DB db9 = DBMaker.volumeDB(volume, contentAlreadyExists).make();
        HTreeMap<String, Long> map9 = db9.hashMap("map", Serializer.STRING, Serializer.LONG).create();
        map9.put("something", 123456L);
        System.out.println(map9.get("something"));
    }
}
