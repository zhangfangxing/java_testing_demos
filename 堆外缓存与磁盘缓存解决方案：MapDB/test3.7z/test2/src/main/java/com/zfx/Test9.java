package com.zfx;

import org.mapdb.*;
import org.mapdb.serializer.SerializerArray;

import java.util.concurrent.ConcurrentMap;

/**
 * MapDB的序列化
 */
public class Test9 {
    public static void main(String[] args) {
        DB db = DBMaker.fileDB("file.db").make();
        ConcurrentMap<String,Long> map1 = db.hashMap("map", Serializer.STRING, Serializer.LONG).create();
        HTreeMap.KeySet<String> set1 = db.hashSet("set", Serializer.STRING).create();
        map1.put("something", 123456L);
        set1.add("123");
        set1.add("456");
        System.out.println(map1.get("something"));
        System.out.println(set1.getMap().keySet());

//        HTreeMap<byte[], Long> map = db.hashMap("map")
//                .keySerializer(Serializer.BYTE_ARRAY)
//                .valueSerializer(Serializer.LONG)
//                .create();
//
//        BTreeMap<Object[], Long> map = db.treeMap("map")
//                .keySerializer(new SerializerArray(Serializer.JAVA))
//                .keySerializer(new SerializerArray(Serializer.STRING))
//                .createOrOpen();
    }
}
