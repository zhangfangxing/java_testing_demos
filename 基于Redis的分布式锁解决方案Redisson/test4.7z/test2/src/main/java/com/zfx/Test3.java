package com.zfx;

/**
 * 体验单机多线程死锁
 */
class ThreadA implements Runnable{
    public String username;
    private Object obj1 = new Object();
    private Object obj2 = new Object();
    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public void run() {
        if (username.equals("zhangfangxing")) {
            synchronized (obj1) {
                System.out.println("zhangfangxing obj1 username: " + username + ",threadname:" + Thread.currentThread().getName());
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                synchronized (obj2) {
                    System.out.println("zhangfangxing obj2" + ",threadname: " + Thread.currentThread().getName());
                }
            }
        }
        if (username.equals("zfx")) {
            synchronized (obj2) {
                System.out.println("zfx obj1 username:" + username + ",threadname: " + Thread.currentThread().getName());
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                synchronized (obj1) {
                    System.out.println("zfx obj2" + ",threadname: " + Thread.currentThread().getName());
                }
            }
        }
    }
}

public class Test3{
    public static void main(String[] args) {
        ThreadA a = new ThreadA();
        a.setUsername("zhangfangxing");
        Thread t1 = new Thread(a);
        t1.start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        a.setUsername("zfx");
        Thread t2 = new Thread(a);
        t2.start();
    }
}