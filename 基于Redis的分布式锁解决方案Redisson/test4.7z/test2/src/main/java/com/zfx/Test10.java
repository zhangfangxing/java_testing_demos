package com.zfx;
import java.util.concurrent.CountDownLatch;
/**
 * Redisson的闭锁CountDownLatch
 */
public class Test10 {

    public static void main(String[] args) {
        CountDownLatch countDownLatch = new CountDownLatch(3);
        new Thread(new DoSomething2(countDownLatch, 2000)).start();
        new Thread(new DoSomething2(countDownLatch, 1000)).start();
        new Thread(new DoSomething2(countDownLatch, 2000)).start();
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("主线执行结束");
    }
}
class DoSomething2 implements Runnable {
    private CountDownLatch countDownLatch;
    private long sleepTime;

    public DoSomething2(CountDownLatch countDownLatch, long sleepTime) {
        this.countDownLatch = countDownLatch;
        this.sleepTime = sleepTime;
    }

    @Override
    public void run() {
        try {
            Thread.sleep(sleepTime);
            System.out.println("多线程执行结束"+Thread.currentThread().getName());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            countDownLatch.countDown();
        }
    }
}