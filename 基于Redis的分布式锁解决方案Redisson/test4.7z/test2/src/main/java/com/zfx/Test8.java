package com.zfx;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
/**
 * Redisson的读写锁（ReadWriteLock）
 */
public class Test8 {

    final static ReadWriteLock rwLock = new ReentrantReadWriteLock();
    final static Lock readLock = rwLock.readLock();//读锁
    final static Lock writeLock = rwLock.writeLock();//写锁
    static int count = 0;
    public static void main(String[] args) {
        for (int i = 0; i < 3; i++) {
            new Thread(() -> {
                System.out.println(Thread.currentThread().getName() + ":" + get());
            }).start();
        }

        for (int i = 0; i < 3; i++) {
            new Thread(() -> {
                System.out.println(Thread.currentThread().getName() + " add");
                add();
            }).start();
        }

        for (int i = 0; i < 3; i++) {
            new Thread(() -> {
                System.out.println(Thread.currentThread().getName() + ":" + get());
            }).start();
        }
    }
    private static int get() {
        readLock.lock();
        try {
            return count;
        } finally {
            readLock.unlock();
        }
    }
    private static void add() {
        writeLock.lock();
        try {
            count++;
        } finally {
            writeLock.unlock();
        }
    }
}
