package com.zfx;
import java.util.concurrent.Semaphore;
/**
 * Redisson的信号量（Semaphore）
 */
public class Test9 {

    public static void main(String[] args) {
        final Semaphore semp = new Semaphore(5);// 只能5个线程同时访问
        for (int i = 0; i < 10; i++) {
            Thread thread = new Thread(new DoSomething(semp, i));
            thread.start();
        }
    }
}
class DoSomething implements Runnable{
    private Semaphore semp;
    private int i;

    public DoSomething(Semaphore semp,int i) {
        this.semp = semp;
        this.i = i;
    }

    @Override
    public void run() {
        try {
            semp.acquire();// 获取许可
            System.out.println("用户：" + i + "获得许可进入run");
            Thread.sleep((long) (Math.random() * 1000));
            semp.release();// 访问完后，释放
            System.out.println("用户：" + i + "访问结束，此信号量中当前可用的许可证数" + semp.availablePermits());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}