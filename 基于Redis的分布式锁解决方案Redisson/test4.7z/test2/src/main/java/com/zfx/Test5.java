package com.zfx;

import java.util.concurrent.locks.ReentrantLock;

/**
 * Redisson的公平锁（Fair Lock）
 */
public class Test5 {

    public static void main(String[] args) {
        MyLock lock=new MyLock ();
        Thread th1=new Thread(lock);
        Thread th2=new Thread(lock);
        th1.start();
        th2.start();
    }
}
class MyLock implements Runnable{
    //创建公平锁
    private static ReentrantLock lock=new ReentrantLock(true);
    public void run() {
        while(true){
            lock.lock();
            try{
                System.out.println(Thread.currentThread().getName()+"获得锁");
            }finally{
                lock.unlock();
            }
        }
    }
}