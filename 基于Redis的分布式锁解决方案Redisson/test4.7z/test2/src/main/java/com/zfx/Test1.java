package com.zfx;

/**
 * 初步体验高并发下超买或超卖bug
 */
class MyThread extends Thread{
    private int count=0;
    public MyThread(int count) {
        this.count = count;
    }
    @Override
    public void run(){
        count --;
        System.out.print(Thread.currentThread().getName() + "~" + count + "。");
    }
}
public class Test1{
    private static int count = 50;
    public static void main(String[] args){
        MyThread myThread = new MyThread(count);
        for(int i = 0; i < 30; i++){
            Thread thread = new Thread(myThread, "i+" + i);
            thread.start();
        }
    }
}