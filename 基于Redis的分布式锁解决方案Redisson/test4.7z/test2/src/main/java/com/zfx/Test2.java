package com.zfx;

/**
 * 用synchroinzed解决单机超买或超卖bug
 */
class MyThread2 extends Thread{
    private int count=0;
    public MyThread2(int count) {
        this.count = count;
    }
    @Override
    synchronized public void run(){
        count --;
        System.out.print(Thread.currentThread().getName() + "~" + count + "。");
    }
}

public class Test2{
    private static int count = 50;
    public static void main(String[] args){
        MyThread2 myThread = new MyThread2(count);
        for(int i = 0; i < 30; i++){
            Thread thread = new Thread(myThread, "i+" + i);
            thread.start();
        }
    }
}