package com.zfx;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

public class Test11 {
    public static void main(String[] args) {
        // 创建一个带有RemovalListener监听的缓存
        Cache<String, String> cache = CacheBuilder.newBuilder().removalListener(new MyRemovalListener()).build();
        cache.put("myKey", "myValue");
        // 手动清除数据
        cache.invalidate("myKey");
        System.out.println("获取我的Key"+cache.getIfPresent("myKey")); // null
    }
}
// 创建一个监听器
class MyRemovalListener implements RemovalListener<String, String> {
    @Override
    public void onRemoval(RemovalNotification<String, String> notification) {
        String message = String.format("修改的key=%s,修改的value=%s,修改的原因=%s", notification.getKey(), notification.getValue(), notification.getCause());
        System.out.println("已被删除的数据"+message);
    }
}
