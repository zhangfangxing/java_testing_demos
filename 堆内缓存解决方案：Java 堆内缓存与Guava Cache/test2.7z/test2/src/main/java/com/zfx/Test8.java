package com.zfx;

import com.google.common.collect.Range;
import com.google.common.collect.RangeSet;
import com.google.common.collect.TreeRangeSet;

/**
 * RangeSet
 */
public class Test8 {
    public static void main(String[] args) {
        //案例1
        RangeSet<Integer> rangeSet = TreeRangeSet.create();
        rangeSet.add(Range.closed(1, 10)); // {[1,10]}
        rangeSet.add(Range.closedOpen(11, 15));//不相连区间{[1,10], [11,15)}
        rangeSet.add(Range.closedOpen(15, 20)); //相连区间 {[1,10], [11,20)}
        rangeSet.add(Range.openClosed(0, 0)); //空区间{[1,10], [11,20)}
        rangeSet.remove(Range.open(5, 10)); //分割[1, 10]; {[1,5], [10,10], [11,20)}
        System.out.println(rangeSet);//[[1..5], [10..10], [11..20)]
//        //案例2
//        RangeSet<Integer> rangeSet = TreeRangeSet.create();
//        rangeSet.add(Range.closed(1, 10)); // {[1,10]}
//        rangeSet.add(Range.closed(1, 10)); // {[1,10]}
//        System.out.println(rangeSet);//[[1..10]]
//        //案例3
//        RangeSet<Integer> rangeSet = TreeRangeSet.create();
//        rangeSet.add(Range.closed(1, 10)); // {[1,10]}
//        rangeSet.add(Range.closed(2, 10)); // {[2,10]}
//        System.out.println(rangeSet);//[[1..10]]
//        //案例4
//        Range.closed(3, 5).intersection(Range.open(5, 10)); //返回(5, 5]
//        Range.closed(0, 9).intersection(Range.closed(3, 4)); //返回[3, 4]
//        Range.closed(0, 5).intersection(Range.closed(3, 9)); //返回[3, 5]
//        Range.open(3, 5).intersection(Range.open(5, 10)); // throws IllegalArgumentException
//        Range.closed(1, 5).intersection(Range.closed(6, 10)); // throws IllegalArgumentException
    }
}
