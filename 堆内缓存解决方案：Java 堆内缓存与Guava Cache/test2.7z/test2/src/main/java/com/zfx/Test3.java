package com.zfx;

import java.util.Optional;

/**
 * 使用GuavaCache的核心代码
 */
public class Test3 {
    public static void main(String[] args) {
        Optional<Integer> possible = Optional.of(5);
        System.out.println(possible.isPresent());// returns true
        System.out.println(possible.get());// returns 5
    }
}
