package com.zfx;

import com.google.common.cache.*;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

/**
 * 参数化构建Guava Cache
 */
public class Test10 {
    private static Cache<Object,Object> cache = CacheBuilder.newBuilder()
            .expireAfterWrite(3, TimeUnit.SECONDS)
            .expireAfterAccess(3, TimeUnit.SECONDS)
            .weakValues()
            .weakKeys()
            //.softValues()
            .concurrencyLevel(8)
            .initialCapacity(10)
            .maximumSize(2000)
            .recordStats()
            .removalListener(new RemovalListener<Object, Object>() {
                @Override
                public void onRemoval(RemovalNotification<Object, Object> notification) {
                    System.out.println(notification.getKey() + " was removed, cause is " + notification.getCause());
                }
            })
            .build(new CacheLoader<Object, Object>() {
                @Override
                public Object load(Object object) throws Exception {
                    return object;
                }
            });

    public static void main(String[] args) {
        //省略Guava Cache构建代码
        ConcurrentMap<Object, Object> asMap = cache.asMap();
        asMap.put(1, 2);
        System.out.println(asMap.get(1));
        asMap.remove(1);
        System.out.println(asMap.get(1));
        System.out.println(cache.asMap().get(1));


    }
}
