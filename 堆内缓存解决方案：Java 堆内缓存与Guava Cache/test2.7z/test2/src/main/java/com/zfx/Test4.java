package com.zfx;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import java.util.Collection;

/**
 * Multiset
 */
public class Test4 {
    public static void main(String[] args) {
        Multimap<String,Object> myMultimap = ArrayListMultimap.create();//构造
        myMultimap.put("name", "zfx1");//添加元素
        myMultimap.put("name", "zfx2");//添加元素
        myMultimap.put("name", "zfx3");//添加元素
        myMultimap.put("name", "zfx4");//添加元素
        Collection<Object> zfx = myMultimap.get("name");//查询键值为name的元素
//返回Collenction集合，输入为[zfx1, zfx2, zfx3, zfx4, zfx5]
    }
}
