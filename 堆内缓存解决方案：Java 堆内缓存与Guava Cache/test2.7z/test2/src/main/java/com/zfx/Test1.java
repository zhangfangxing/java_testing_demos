package com.zfx;

/**
 * CAS锁
 */
public class Test1 {
    //调用 MyCAS代码
    public static void main(String[] args) {
        MyCAS myCAS = new MyCAS();
        boolean flag = myCAS.set(0, 1);
        System.out.println("flag:"+flag+",get():"+myCAS.get());
        //执行结果：flag:false,get():1
    }
}
class MyCAS {
    private int value;//要更新的变量（旧值）
    public int get() {
        return value;
    }
    public boolean set(int expectedValue, int newValue) {
        int oldValue = value;
        if (oldValue == expectedValue) {
            value = newValue;
        }
        return value == expectedValue;
    }
}
