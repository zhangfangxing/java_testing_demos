package com.zfx;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import java.util.Map;
import java.util.Set;

/**
 * Table
 */
public class Test6 {
    public static void main(String[] args) {
        Table<String, String, String> table = HashBasedTable.create();
        table.put("103.555", "99.9", "我家");
        table.put("103.555", "99.8", "狗狗宿舍");
        table.put("103.555", "99.7", "我公司");
        table.put("103.554", "99.6", "她公司");
        table.put("103.554", "99.5", "猫猫宿舍");
        table.put("103.554", "99.4", "海豚宿舍");
        table.put("103.553", "99.3", "松鼠宿舍");
        table.put("103.553", "99.2", "猪猪宿舍");

        Map<String,String> tableMap1 =  table.row("103.555");
        for(Map.Entry<String, String> entry : tableMap1.entrySet()){
            System.out.println("tableMap11: " + entry.getKey() + ", tableMap12: " + entry.getValue());
        }
        Set<String> tableMap2 = table.rowKeySet();
        for(String employer: tableMap2){
            System.out.println("tableMap22: " + employer + " ");
        }
        Map<String,String> tableMap3 =  table.column("99.2");
        for(Map.Entry<String, String> entry : tableMap3.entrySet()){
            System.out.println("tableMap31: " + entry.getKey() + ", tableMap32: " + entry.getValue());
        }
    }
}
