package com.zfx;

import java.io.Serializable;
import java.util.HashMap;

/**
 * 分段锁算法（Segment）
 */
public class Test2 {
    public static void main(String[] args) {
        MySegmentMap<String, String> mySegmentMap = new MySegmentMap<String, String>();
        new Thread(new MyThread(mySegmentMap,"put","1","2")).start();
        new Thread(new MyThread(mySegmentMap,"get","1","")).start();
        new Thread(new MyThread(mySegmentMap,"get","2","")).start();
    }
}
class MyThread implements Runnable{
    MySegmentMap mySegmentMap = null;
    String method = "";
    String key = "";
    Object value = "";;
    public MyThread(MySegmentMap mySegmentMap, String method, String key, String value){
        this.mySegmentMap = mySegmentMap;
        this.method = method;
        this.key = key;
        this.value = value; /*get时value值可不填*/
    }
    @Override
    public void run() {
        switch (method) {
            case "put": mySegmentMap.put(key, value); break;
            case "get": System.out.println("输出："+mySegmentMap.get(key)); break;
        }
    }
}



class MySegmentMap<K,V> implements Serializable {
    private HashMap<K, V> hashMap;
    public MySegmentMap() {
        hashMap = new HashMap<>();
    }
    public V put(K key, V value) {
        synchronized (key) {
            try {
//                Thread.sleep(1000000000);
                return hashMap.put(key, value);
            } catch (Throwable e) {}
        }
        return null;
    }
    public V get(K key) {
        synchronized (key) {
            try {
                return hashMap.get(key);
            } catch (Throwable e) {}
        }
        return null;
    }
}