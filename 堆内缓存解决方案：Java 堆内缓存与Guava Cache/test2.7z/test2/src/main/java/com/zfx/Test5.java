package com.zfx;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

/**
 * BiMap
 */
public class Test5 {
    public static void main(String[] args) {
        BiMap<Integer,String> biMap= HashBiMap.create();
        biMap.put(1,"张三");
        biMap.put(2,"李四");
        biMap.put(3,"王五");
        biMap.put(4,"赵六");
        biMap.put(5,"李七");
        biMap.put(4,"小小");

        //通过key值得到value值（注意，key里面的类型根据泛行
        String value= biMap.get(1);
        System.out.println("id为1的value值 --"+value);//返回：id为1的value值 --张三

        //通过value值得到key值
        int key= biMap.inverse().get("张三");
        System.out.println("张三key值 --"+key);//返回：张三key值 --1

        //如果key值重复，那么vakue值会被覆盖
        String valuename= biMap.get(4);
        System.out.println("id为4的value值 --"+valuename);//返回：id为4的value值 --小小
    }
}
