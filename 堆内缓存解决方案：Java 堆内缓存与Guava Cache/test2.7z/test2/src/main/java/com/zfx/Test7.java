package com.zfx;

import com.google.common.collect.ClassToInstanceMap;
import com.google.common.collect.MutableClassToInstanceMap;

/**
 * classToInstanceMap
 */
public class Test7 {

    public static void main(String[] args) {
        ClassToInstanceMap<Number> numberDefaults= MutableClassToInstanceMap.create();
        numberDefaults.putInstance(Integer.class, Integer.valueOf(222));
        System.out.println(numberDefaults.get(Integer.class));//返回222
    }
}
